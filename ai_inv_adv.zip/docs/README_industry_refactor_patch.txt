Industry reference refactor patch
